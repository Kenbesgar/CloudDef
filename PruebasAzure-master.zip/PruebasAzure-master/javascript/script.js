/*$(document).ready(function(){
	var height = $(window).height();
	$('#barraIzquierda').height(height);
});*/

//window.alert("Probando");